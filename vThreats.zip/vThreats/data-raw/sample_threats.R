## code to prepare `sample_threats` dataset goes here

usethis::use_data(sample_threats, overwrite = TRUE)
# Raw sample data for vThreats package

# Create sample threat values (per location)
sample_threats <- data.frame(
  fishing = c(9, 3, 10),
  human_activity = c(6, 5, 8),
  water_level_change = c(2, 4, 6)
)

# Maximum possible values (for normalization)
max_vals <- c(
  fishing = 10,
  human_activity = 10,
  water_level_change = 7
)

# Weights for each threat type
weights <- c(
  fishing = 0.6,
  human_activity = 0.3,
  water_level_change = 0.1
)

# Save datasets for package use
usethis::use_data(sample_threats, overwrite = TRUE)
usethis::use_data(max_vals, overwrite = TRUE)
usethis::use_data(weights, overwrite = TRUE)
