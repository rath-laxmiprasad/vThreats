#' Calculate Threat Score for a Single Location
#'
#' @param threats A named numeric vector of normalized threats (values from 0 to 1)
#' @param weights A named numeric vector of weights (sum to 1)
#' @return Numeric threat score T
#' @export
#'
#' @examples
#' threats <- c(fishing = 0.9, human_activity = 0.6, water_level_change = 0.2)
#' weights <- c(fishing = 0.6, human_activity = 0.3, water_level_change = 0.1)
#' calculate_single_threat(threats, weights)

calculate_single_threat <- function(threats, weights) {
  if (!all(names(threats) %in% names(weights))) {
    stop("Threat and weight names must match")
  }
  sum(threats * weights[names(threats)], na.rm = TRUE)
}

#' Normalize Threats by Maximum Values
#'
#' @param df A data frame with raw threat values (numeric)
#' @param max_vals A named vector with max values for normalization
#' @return A data frame with normalized threat values
#' @export
#'
#' @examples
#' df <- data.frame(
#'   fishing = c(9, 3),
#'   human_activity = c(6, 5),
#'   water_level_change = c(2, 4)
#' )
#' max_vals <- c(fishing = 10, human_activity = 10, water_level_change = 7)
#' normalize_threats(df, max_vals)

normalize_threats <- function(df, max_vals) {
  if (!all(names(max_vals) %in% names(df))) {
    stop("Max value names must match column names of data frame")
  }
  as.data.frame(mapply(`/`, df[names(max_vals)], max_vals))
}

#' Calculate Threat Score for Multiple Locations
#'
#' @param df A data frame of raw threat values per location
#' @param max_vals A named vector of max values for normalization
#' @param weights A named vector of weights (sum to 1)
#' @return A vector of threat intensity scores T
#' @export
#'
#' @examples
#' df <- data.frame(
#'   fishing = c(9, 3, 10),
#'   human_activity = c(6, 5, 8),
#'   water_level_change = c(2, 4, 6)
#' )
#' max_vals <- c(fishing = 10, human_activity = 10, water_level_change = 7)
#' weights <- c(fishing = 0.6, human_activity = 0.3, water_level_change = 0.1)
#' calculate_threat_score(df, max_vals, weights)

calculate_threat_score <- function(df, max_vals, weights) {
  df_norm <- normalize_threats(df, max_vals)
  apply(df_norm, 1, calculate_single_threat, weights = weights)
}

#' Classify Threat Level from T Score
#'
#' @param T A numeric threat score (0 to 1)
#' @return A character string of threat level: Low, Moderate, High, Severe
#' @export
#'
#' @examples
#' T <- c(0.2, 0.4, 0.6, 0.8)
#' classify_threat_level(T)

classify_threat_level <- function(T) {
  ifelse(T < 0.3, "Low",
         ifelse(T < 0.5, "Moderate",
                ifelse(T < 0.7, "High", "Severe")))
}

# Example usage (not exported)
# df <- data.frame(
#   fishing = c(9, 3, 10),
#   human_activity = c(6, 5, 8),
#   water_level_change = c(2, 4, 6)
# )
# max_vals <- c(fishing = 10, human_activity = 10, water_level_change = 7)
# weights <- c(fishing = 0.6, human_activity = 0.3, water_level_change = 0.1)
# T_scores <- calculate_threat_score(df, max_vals, weights)
# levels <- sapply(T_scores, classify_threat_level)
# print(data.frame(T_scores, levels))


