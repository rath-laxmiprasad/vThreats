test_that("multiplication works", {
  expect_equal(2 * 2, 4)
})

test_that("calculate_threat_score works correctly", {
  data(sample_threats)
  data(max_vals)
  data(weights)

  T_scores <- calculate_threat_score(sample_threats, max_vals, weights)

  # Check score is numeric and same length as number of rows
  expect_type(T_scores, "double")
  expect_length(T_scores, nrow(sample_threats))

  # Check all scores are between 0 and 1
  expect_true(all(T_scores >= 0 & T_scores <= 1))
})

test_that("classify_threat_level returns correct labels", {
  T <- c(0.2, 0.4, 0.6, 0.8)
  levels <- classify_threat_level(T)
  expect_equal(levels, c("Low", "Moderate", "High", "Severe"))
})
